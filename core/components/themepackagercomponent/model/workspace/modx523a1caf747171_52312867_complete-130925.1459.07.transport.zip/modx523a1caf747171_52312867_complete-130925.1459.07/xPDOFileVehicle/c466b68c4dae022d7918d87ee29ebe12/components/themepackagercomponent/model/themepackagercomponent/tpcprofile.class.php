<?php
/**
 * @package themepackagercomponent
 */
class pacProfile extends xPDOSimpleObject {}
?>