<?php
return array(
    's3' => array(
        'key' => '',
        'secretKey' => ''
    ),
);