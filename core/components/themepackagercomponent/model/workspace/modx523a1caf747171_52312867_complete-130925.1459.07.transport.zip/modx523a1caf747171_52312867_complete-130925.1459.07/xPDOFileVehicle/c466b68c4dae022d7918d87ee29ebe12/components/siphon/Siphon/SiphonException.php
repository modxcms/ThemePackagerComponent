<?php
namespace Siphon;

/**
 * Defines a Siphon Exception.
 */
class SiphonException extends \Exception {}