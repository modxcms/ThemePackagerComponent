<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b09fece3888176cd0d0c34970a1c1e0d',
      'native_key' => 'b09fece3888176cd0d0c34970a1c1e0d',
      'filename' => 'xPDOFileVehicle/c466b68c4dae022d7918d87ee29ebe12.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'cc86f1faf1369f2d543180ae54b4a1c9',
      'native_key' => 'cc86f1faf1369f2d543180ae54b4a1c9',
      'filename' => 'xPDOFileVehicle/302e9826cc3aac82cd6ea52c2d6d7339.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'eb678c94b913f47d443875c64e0d385e',
      'native_key' => 'eb678c94b913f47d443875c64e0d385e',
      'filename' => 'xPDOScriptVehicle/0da14cb52c7de526070eaab6b38078c9.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modAccessContext',
      'guid' => '1dc39da75f6ffc97c7eaf5307832c207',
      'native_key' => '1dc39da75f6ffc97c7eaf5307832c207',
      'filename' => 'modAccessContext/3797c6b97b6197f75d5716dcfa3f187b.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modAccessPermission',
      'guid' => 'e0bb0bb8a11d9733926a520efb258659',
      'native_key' => 'e0bb0bb8a11d9733926a520efb258659',
      'filename' => 'modAccessPermission/d7e14e9e92e95740ebf7a747cfc49223.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9d13157af5704efacece8771a130823a',
      'native_key' => '9d13157af5704efacece8771a130823a',
      'filename' => 'modAccessPolicy/bd58a83878dc3548ad6f92a9f8636b0e.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd0249563473af36cbae2d8edfbf1a9ac',
      'native_key' => 'd0249563473af36cbae2d8edfbf1a9ac',
      'filename' => 'modAccessPolicyTemplate/fbe7b1fc32b5615813fe1117c20653f4.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '053e80bd1a9309dc6eef2efb3ba0e65b',
      'native_key' => '053e80bd1a9309dc6eef2efb3ba0e65b',
      'filename' => 'modAccessPolicyTemplateGroup/fe7f0df6d48df197dad2dcd0930519fd.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modAction',
      'guid' => '9783cdc517144f8ce02df2c05a99d0dd',
      'native_key' => '9783cdc517144f8ce02df2c05a99d0dd',
      'filename' => 'modAction/a7073f5550a6f97a31dbe08fe2da5fdb.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modActionField',
      'guid' => '79dc4cb357620e4459524bfe33ecd5b0',
      'native_key' => '79dc4cb357620e4459524bfe33ecd5b0',
      'filename' => 'modActionField/0a9950d76da83345addaa466a3f856fd.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modCategory',
      'guid' => 'b64b99d1d44b9ca5457e8f7dcff5f480',
      'native_key' => 'b64b99d1d44b9ca5457e8f7dcff5f480',
      'filename' => 'modCategory/0a46439cdc79c82b5b1cb6a4b3f67f5a.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modCategoryClosure',
      'guid' => 'dacf5e47e199f50ad979eb1c190834ee',
      'native_key' => 'dacf5e47e199f50ad979eb1c190834ee',
      'filename' => 'modCategoryClosure/608f3c2f2de69368832a7e0c6bbd9e0d.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modClassMap',
      'guid' => '21d1a760d9b79964c31771fa1fe11469',
      'native_key' => '21d1a760d9b79964c31771fa1fe11469',
      'filename' => 'modClassMap/398196b3ab0e4e1e355278a8a911f16c.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modContentType',
      'guid' => '518496c97936d01068417282b9c6fe4c',
      'native_key' => '518496c97936d01068417282b9c6fe4c',
      'filename' => 'modContentType/d1285e217f186be73df5a7054a4a7c14.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modContext',
      'guid' => '03d77747aef2e121c3d3251d345e4a32',
      'native_key' => '03d77747aef2e121c3d3251d345e4a32',
      'filename' => 'modContext/8a1850724cbb3b484d7e064ae1927b2c.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modContextSetting',
      'guid' => 'aa70a84dc3845745db491bcff746d7b8',
      'native_key' => 'aa70a84dc3845745db491bcff746d7b8',
      'filename' => 'modContextSetting/1864a14a92f8ef1720e87e3fea3f6849.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modDashboard',
      'guid' => '7bec9f62e4929942968dd779ac79f9c0',
      'native_key' => '7bec9f62e4929942968dd779ac79f9c0',
      'filename' => 'modDashboard/bd973b823f3734f4adf23cb39e864b9a.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '8578eb98429500150e98db413158c45a',
      'native_key' => '8578eb98429500150e98db413158c45a',
      'filename' => 'modDashboardWidget/5b844713471f60471707dfd67778190e.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modDashboardWidgetPlacement',
      'guid' => 'dc90fa947c3c49e6f0df29d308b1bfe8',
      'native_key' => 'dc90fa947c3c49e6f0df29d308b1bfe8',
      'filename' => 'modDashboardWidgetPlacement/6de945ca8b0353d0954ba28091a546d1.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modEvent',
      'guid' => '397a69ceaf8ada559a2cfbcf82c79535',
      'native_key' => '397a69ceaf8ada559a2cfbcf82c79535',
      'filename' => 'modEvent/a24cd8278bec6a9afa5da76b38295157.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modLexiconEntry',
      'guid' => '908a09f15286e4d57133afdd1de5e372',
      'native_key' => '908a09f15286e4d57133afdd1de5e372',
      'filename' => 'modLexiconEntry/4be15b972bfa49d0666e4fac8c4f6733.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modMenu',
      'guid' => '1cf8e773b810ade6a958f38c3f68d470',
      'native_key' => '1cf8e773b810ade6a958f38c3f68d470',
      'filename' => 'modMenu/4fcd094a78d5b7a0c4f3872a4d0be9cd.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modNamespace',
      'guid' => '65d0f1a1706c2104bb8ce401cbaeaa78',
      'native_key' => '65d0f1a1706c2104bb8ce401cbaeaa78',
      'filename' => 'modNamespace/c14b3227e45a917a9aec5b7ad641f547.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modDocument',
      'guid' => '86944af0d898c118cef8834d390e6f9e',
      'native_key' => '86944af0d898c118cef8834d390e6f9e',
      'filename' => 'modDocument/5e5b05e18f29d83afbd6d6bd87678de7.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0f76be856c3a92efdb22a1250a0add8',
      'native_key' => 'f0f76be856c3a92efdb22a1250a0add8',
      'filename' => 'modSystemSetting/67acaac58464bad3689a1e4454656461.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modTemplate',
      'guid' => '251fa3861a262f516c09938043e6d6e0',
      'native_key' => '251fa3861a262f516c09938043e6d6e0',
      'filename' => 'modTemplate/6dd0060922ad74ecc2cbbfaafa282feb.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modUser',
      'guid' => 'ea2271a2e825125f6c5eb5dec99cae37',
      'native_key' => 'ea2271a2e825125f6c5eb5dec99cae37',
      'filename' => 'modUser/93e528f68f9feb07b792a7e3ff891e6c.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modUserProfile',
      'guid' => '40c376e7fad6f31afa70e1233348b7f1',
      'native_key' => '40c376e7fad6f31afa70e1233348b7f1',
      'filename' => 'modUserProfile/ccbcb6780ae79061689cc8eaa4919ee6.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modUserGroup',
      'guid' => 'fd875922d0d02a922523979666ae3e17',
      'native_key' => 'fd875922d0d02a922523979666ae3e17',
      'filename' => 'modUserGroup/86c227513470e0c35229bee341e5b1bc.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modUserGroupMember',
      'guid' => '8b19f5f041e91692a2eec0a79b01c4eb',
      'native_key' => '8b19f5f041e91692a2eec0a79b01c4eb',
      'filename' => 'modUserGroupMember/4ce12850fbcb7dc7ea461c61d5d92a23.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '45dc0d4223348a45d57ed36e869d4afe',
      'native_key' => '45dc0d4223348a45d57ed36e869d4afe',
      'filename' => 'modUserGroupRole/9c01c2308c9eff4a8abf3b99227c8507.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modWorkspace',
      'guid' => 'b9766d90a7ad4c2d46fb61910453a21b',
      'native_key' => 'b9766d90a7ad4c2d46fb61910453a21b',
      'filename' => 'modWorkspace/67fe8b2523895981cdd7a00678f23b9e.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'd33a48053d281ea06c2c9076af6055e7',
      'native_key' => 'd33a48053d281ea06c2c9076af6055e7',
      'filename' => 'modTransportProvider/c1aa39bb7f1445539be37ce9615e8348.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => '\\Siphon\\Transport\\SiphonXPDOCollectionVehicle',
      'class' => 'modFileMediaSource',
      'guid' => '48866bae87d5971f76cf2335478c89e4',
      'native_key' => '48866bae87d5971f76cf2335478c89e4',
      'filename' => 'modFileMediaSource/692d85e9ab6c5d1afea11cf3499da981.vehicle',
    ),
  ),
);