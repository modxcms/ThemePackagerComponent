<?php
/**
 * @package themepackagercomponent
 */
class tpcProfile extends xPDOSimpleObject {}
