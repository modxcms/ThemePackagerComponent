<?php
/**
 * @package themepackagercomponent
 */
interface Modx_Package_Builder {

    //function init(modX &$modx, array $param);
    function handle();

}